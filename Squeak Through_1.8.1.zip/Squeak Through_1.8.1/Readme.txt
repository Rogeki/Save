Squeak Through 1.8.1
====================

Version 1.8.1 was released November 29, 2020, and was tested using Factorio v1.1.1.
It primarily features code by Nommy, with contribution from Lupin and Foxite, and is maintained by Supercheese, who is grateful for strong community support.

This small mod reduces the collision boxes for many structures, allowing you to "squeak through" them while walking around your base.
Say goodbye to the frustration of having your path blocked by your steam engines or solar panels when walking around your base!

You can toggle the collision box shrinking for each type of entity using the in-game mod settings. Altering these settings will require you to restart the game.


See also the associated forum thread: http://www.factorioforums.com/forum/viewtopic.php?f=91&t=16476
