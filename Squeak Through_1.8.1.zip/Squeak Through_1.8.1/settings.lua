data:extend({{
	type = "string-setting",
	name = "squeakthrough-mod-compatibility",
	order = "ad",
	setting_type = "startup",
	default_value = "opt-out",
	allowed_values =  { "opt-out", "opt-in", "force" }
}})