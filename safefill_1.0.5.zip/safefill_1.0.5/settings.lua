data:extend({
  {
    type = "string-setting",
    name = "safefill-cost",
    setting_type = "startup",
    default_value = "Normal",
    allowed_values = {"Cheap", "Normal", "Expensive"},
    order = "b"
  },
  {
    type = "bool-setting",
    name = "safefill-green-water",
    setting_type = "startup",
    default_value = true,
	order = "c"
  }
})
